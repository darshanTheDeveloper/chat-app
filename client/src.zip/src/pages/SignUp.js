import React, { useEffect, useState } from 'react'
import '../components/styles.css'

export default function SignUp() {
  const [user, setUser] = useState({ firstName: '', lastName: '', email: '', username: '', password: '' })

  function onSignup() {
    fetch('/api/signup', {
      method: "POST",
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(user)
    })
      .then(res => res.json())
      .then(data => console.log(data))
      .catch(err => console.log(err))
  }

  return (
    <div className='Signup'>
      <form autoComplete='off' onSubmit={(e) => e.preventDefault()}>
        <h1>SIGNUP</h1>
        <div>
          <div className='name'>
            <input
              type='text'
              value={user.firstName}
              placeholder='First Name'
              onChange={(e) => setUser((prev) => ({ ...prev, firstName: e.target.value }))}
            />
            <input
              type='text'
              value={user.lastName}
              placeholder='Last Name'
              onChange={(e) => setUser((prev) => ({ ...prev, lastName: e.target.value }))}
            />
          </div>
          <input
            type='email'
            name="email"
            value={user.email}
            placeholder='Enter the email'
            autoComplete="off"
            onChange={(e) => {
              setUser((prev) => {
                return {
                  ...prev,
                  email: e.target.value
                }
              })
            }}
          />
          <input
            type='text'
            name='username'
            value={user.username}
            placeholder='Enter the Username'
            autoComplete="off"
            onChange={(e) => {
              setUser((prev) => {
                return {
                  ...prev,
                  username: e.target.value
                }
              })
            }}
          />
          <input
            type='password'
            name="password"
            value={user.password}
            placeholder='Enter the password'
            autoComplete="off"
            onChange={(e) => {
              setUser((prev) => {
                return {
                  ...prev,
                  password: e.target.value
                }
              })
            }}
          />
        </div>
        <button
          type='submit'
          onClick={onSignup}>SIGNUP</button>
      </form>
    </div>
  )
}
