import React, { useState } from 'react'
import '../components/styles.css'

export default function Login() {
  const [user, setUser] = useState({ username: '', password: '' })
  function handleSubmit(){
    fetch('/api/login',{
      method:"POST",
      headers:{
        'Content-Type': 'application/json'
      },
      body:JSON.stringify(user)
    })
  }

  return (
    <div className='Login'>
      <form autoComplete='off' onSubmit={(e)=>e.preventDefault()}>
        <h1>LOGIN</h1>
        <div>
          <input
            type='text'
            value={user.username}
            placeholder='Enter the username'
            autoCapitalize='false'
            autoFocus="off"
            autoComplete='off'
            onChange={(e)=>{
              setUser((prev)=>({...prev,username:e.target.value}))
            }}
          />
          <input
            type='password'
            value={user.password}
            placeholder='Enter the password'
            onChange={(e)=>setUser((prev)=>({...prev,password:e.target.value}))}
          />
        </div>
        <button type='submit' onClick={handleSubmit}>LOGIN</button>
      </form>
    </div>
  )
}
