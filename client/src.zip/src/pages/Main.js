import { useEffect, useState } from 'react';
import '../App.css';
import Chats from '../components/Chats';
import Icons from '../components/Icons';
import Messages from '../components/Messages';

export default function Main() {
  const [users,setUsers]  = useState([])

  useEffect(()=>{
     fetch('/api/users')
     .then(res=>res.json())
     .then(data=>setUsers(data))
  },[])

  return (
    <div className='Main'>
      <Icons/>
      <Chats usersData={users}/>
      <Messages/>
    </div>
  )
}
