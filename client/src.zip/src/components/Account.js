import AccountCircleRoundedIcon from '@mui/icons-material/AccountCircleRounded';
import { Drawer } from "@mui/material";
import { useState } from "react";

export default function Account(props) {
    const [open, setOpen] =useState(false);

    const toggleDrawer = (newOpen) => () => {
        setOpen(newOpen);
    };

    return (
        <div>
            <AccountCircleRoundedIcon onClick={toggleDrawer(true)}/>
            <Drawer open={open} onClose={toggleDrawer(false)}>
            </Drawer>
        </div>
    )
}
