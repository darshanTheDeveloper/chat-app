import './styles.css'
import SettingsIcon from '@mui/icons-material/Settings';
import Account from './Account';
import { useState, useEffect } from 'react'

export default function Icons() {
  const [user, setUser] = useState({
    firstName: '',
    lastName: '',
    email: '',
    username: ''
  })

  useEffect(() => {
    fetch('/api/current-user')
      .then(res => res.json())
      .then(data =>setUser(data[0]))
  }, [])

  return (
    <div className='Icons'>
      <i className="fa-brands fa-whatsapp fa-xl" style={{ color: 'springgreen' }}></i>
      <div>
        <Account user={user} />
        <SettingsIcon />
      </div>
    </div>
  )
}
