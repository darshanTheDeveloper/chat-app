import React, { useState, useEffect } from 'react';
import './styles.css';
import AttachmentIcon from '@mui/icons-material/Attachment';
import EmojiEmotionsOutlinedIcon from '@mui/icons-material/EmojiEmotionsOutlined';
import SendRoundedIcon from '@mui/icons-material/SendRounded';
import io from 'socket.io-client';

// Define the endpoint for your Socket.IO server
const ENDPOINT = 'http://localhost:5000';

export default function Input({handleSend}) {
  const [message, setMessage] = useState('');
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    const newSocket = io(ENDPOINT);
    setSocket(newSocket);
    return () => newSocket.close();
  }, [setSocket]);

  function handleClick() {
    if (socket) {
      socket.emit('message', { message });
      setMessage('');
    }
    handleSend(message)
  }

  return (
    <div className='Input'>
      <div>
        <AttachmentIcon sx={{ color: 'rgb(0, 209, 105)' }} />
        <input 
          type='text'
          value={message}
          placeholder='Write message....'
          onChange={(e) => setMessage(e.target.value)}
        />
        <EmojiEmotionsOutlinedIcon sx={{ color: 'rgb(0, 209, 105)' }} />
      </div>
      <SendRoundedIcon
        sx={{ color: 'blue' }}
        type='submit'
        onClick={handleClick}
      />
    </div>
  );
}
