import './styles.css'
import React from 'react'
import Search from './Search'


export default function Chats({usersData}) {
  return (
    <div className='Chats'>
      <h1>Chats</h1>
      <Search/>
      <div>
        {
          usersData.map((user)=>{
            return(
              <div className='user'>
                  <h2>{`${user.firstName} ${user.lastName}`}</h2>
              </div>
            )
          })
        }
      </div>
    </div>
  )
}
