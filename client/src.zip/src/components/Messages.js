import React, { useState } from 'react'
import Input from './Input'
import './styles.css'

export default function Messages() {
  const [message,setMessage] = useState('')
  function sendMessage(msg){
    setMessage(msg)
  }
  return (
    <div className='Messages'>
      <Input handleSend={sendMessage}/>
    </div>
  )
}
